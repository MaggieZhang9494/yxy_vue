/*
 * Copyright 2014-2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
<template>
    <div class="login-bg" :style="{backgroundImage: 'url(' + bgLogin +')'}">
        <div style="position: relative;left:100px;top:17%;width:calc(60% - 100px);font-size:30px;color:#fff;font-weight:400;">{{$t('message.login.loginDesc3')}}</div>
        <div class="login-bg-child">
            <!-- <div class="login-bg-sub" :style="{'backgroundImage': 'url(' + bgSubLogin +')'}">
                <div style="position: relative;left:30px;top:30px;font-size:25px;color:#fff;font-weight:500;">{{$t('message.login.loginDesc1')}}</div>
                <div style="position: relative;left:30px;top:35px;font-size:20px;color:#fff;">{{$t('message.login.loginDesc2')}}</div>
            </div> -->
            <div class="login">
                <div class="loginLogo">
                    <el-image class="icon" :src="logoPng"></el-image>
                    <!-- <svg class="icon" aria-hidden="true">
                        <use xlink:href="#wbs-icon-WeBASE"></use>
                    </svg> -->
                    <p class="logo-content">{{$t('message.login.welcome')}}</p>
                    <!-- <i class="wbs-icon-WeBASE"></i> -->
                    <!-- <h2 class="login-title">WeBASE</h2> -->
                </div>
                
                <div class="login-content">
                    <template>
                        <el-form ref="loginForm" :model="loginForm" :rules="rules" class="login-form">
                            <el-form-item class="newItem" :label="$t('message.login.account')" prop="user">
                                <el-input v-model="loginForm.user" :placeholder="$t('message.login.accountInput')">
                                </el-input>
                            </el-form-item>
                            <el-form-item class="newItem" :label="$t('message.login.password')" prop="password">
                                <el-input v-model="loginForm.password" :placeholder="$t('message.login.passwordInput')" type="password">
                                </el-input>
                            </el-form-item>
                            <el-form-item class="newItem" :label="$t('message.login.verCode')" prop="vercode">
                                <div style="width: 100%;text-align:left;">
                                    <el-input style="width: calc(100% - 82px);" v-model="loginForm.vercode" :placeholder="$t('message.login.verCodeInput')" @keyup.enter.native="submit('loginForm')">
                                    </el-input>
                                    <span class="codeUrlImg">
                                        <img style="width: 100%;height: 100%" :src="codeUrl" alt="" @click="changeCode()">
                                    </span>
                                </div>
                            </el-form-item>
                        </el-form>
                    </template>
                    <div class="msg-wrapper">
                        <div class="msg-error" v-show="msgError || timeout">
                            <i class="el-icon-remove"></i>
                            <span v-if="msgError">{{msgErrorContent || $t('message.login.loginFail')}}</span>
                            <span v-else-if="timeout">{{$t('message.login.overtime')}}</span>
                        </div>
                    </div>
                </div>
                <div style="position: relative;top: 0px;">
                    <!-- <i class="wbs-icon-overview" ></i>
                    <i class="wbs-icon-arrow-down" ></i>
                    <i class="iconfont wbs-jiedianguanli" ></i>
                    <el-avatar icon="wbs-icon-overview"></el-avatar> -->
                    <el-button @click="submit('loginForm')" type="primary" class="login-submit" :loading="logining">{{$t('message.login.login')}}</el-button>
                </div>
                <div style="position: relative;top: 25px;height:40px;text-align:center;">
                    <el-popover placement="bottom" width="80px" trigger="click" v-model="visible">
                        <ul class="group-item">
                            <li class="group-item-list" v-for='item in localLanaugaeList' :key='item.key' @click='changeLocalLanuage(item)'>{{item.name}}</li>
                        </ul>
                        <div slot="reference" class="loginlanauageClass">
                            <span class="contant-head-name" style="color: #666;margin-left:0px;font-size:14px;">{{localLanaugaeName}}</span>
                            <el-image style="width:15px;height:15px;top:2px;" src="../../static/image/icon_down_666.png"> </el-image>
                        </div>
                    </el-popover>
                </div>
                
            </div>
        </div>
        <div class="remarkNum">
            <span class="remarkNumSpanLeft">{{$t('message.common.webDesc')+"&nbsp;"}}</span>
            <div class="remarkNumSpanRight">
                <span class="remarkNumSpan" @click="goRemarkUrl">{{$t('message.common.icpMsg1')}}</span>
                <span class="remarkNumSpanTouch">{{"&nbsp;"+$t('message.common.icpMsg2')}}</span>  
            </div>
        </div>
    </div>
</template>
<script>
import { login,loginYX, networkList, haveNode, getYXPictureCheckCode,getPictureCheckCode,getAccountDetail, setLanguage } from "@/util/api";
import url from "@/util/url"
import router from "@/router";
import bg from "@/../static/image/banner.png";
// import bgsub from "@/../static/image/bg_sub.png";
import logo from "@/../static/image/logo-2 copy@1.5x.png";
import { delCookie } from '@/util/util'
import errcode from "@/util/errcode";
const sha256 = require("js-sha256").sha256;
export default {
    name: "login",
    data: function () {
        return {
            bgLogin: bg,
            logoPng: logo,
            // bgSubLogin:bgsub,
            logining: false,
            msgError: false,
            msgErrorContent: "",
            timeout: false,
            codeUrl: url.codeUrl,
            loginForm: {
                user: "",
                password: "",
                vercode: "",
            },
            rules: {
                user: [{ required: true, message: this.$i18n.t('message.login.accountInput'), trigger: "blur" }],
                password: [
                    { required: true, message: this.$i18n.t('message.login.passwordInput'), trigger: "blur" }
                ],
                vercode: [
                    { required: true, message: this.$i18n.t('message.login.verCodeInput'), trigger: "blur" }
                ]
            },
            authToken: null,
            newUserRules: {
                user: [
                    { required: true, message: this.$i18n.t('message.login.accountInput'), trigger: "blur" },
                    {
                        min: 1,
                        max: 32,
                        message: this.$i18n.t('message.login.accountAlert'),
                        trigger: "blur"
                    }
                ],
                password: [
                    { required: true, message: this.$i18n.t('message.login.passwordInput'), trigger: "blur" },
                    {
                        min: 5,
                        max: 5,
                        message: this.$i18n.t('message.login.errorPwdAlert'),
                        trigger: "blur"
                    },
                    {
                        pattern: /admin/,
                        message: this.$i18n.t('message.login.correctPwdAlert'),
                        trigger: "blur"
                    }
                ]
            },
            visible: false,
            localLanaugaeName:'中文简体',
            localLanaugaeList:[{
                key:'zh-cn',
                name:"中文简体"
            },{
                key:'en',
                name:"English"
            }]
        };
    },
    mounted: function () {
        this.changeCode()
    },
    created(){
        let language = localStorage.getItem("internationalization");
        console.log("language..",language);
        if (this.isNullData(language)) {
            this.localLanaugaeName = '中文简体';
        }else{
            this.localLanaugaeName = (language == 'zh-cn')?'中文简体':"English";
        }
    },
    methods: {
        //切换语言
        changeLocalLanuage: function (val) {
            let _this = this;

            this.visible = false;
            this.localLanaugaeName = val.name

            if (localStorage.getItem("internationalization")) {
                let key = localStorage.getItem("internationalization");
                if(val.key == key){
                    return;
                }
            }

            let params = {
                language:val.key
            }
            setLanguage(params).then(res=>{
                if (res.data.code === 0) {

                    location.reload();
                    localStorage.setItem("internationalization", val.key);

                    setTimeout(()=>{
                        _this.$message({
                        type: "success",
                        message: "设置成功"
                    });
                    },1000)

                } else {
                    let message = res.data.message?res.data.message:this.errcode.errCode.isCN?this.errcode.errCode[res.data.code].cn:this.errcode.errCode[res.data.code].en;
                    this.$message({
                        type: "error",
                        message: message
                    });
                }
            }).catch(err=>{
                let message = this.errcode.errCode.isCN?this.errcode.errCode[err.data.code].cn:this.errcode.errCode[err.data.code].en;
                message = message?message:this.$i18n.t('message.common.systemError');
                this.$message({
                    type: "error",
                    message: message
                });
            })
        },
        //跳转备案链接
        goRemarkUrl(){
            window.open('http://www.beian.miit.gov.cn', '_blank');
        },
        submit: function (formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.logining = true;
                    this.userLogin();
                } else {
                    return false;
                }
            });
        },
        changeCode: function () {
            this.codeUrl = "";
            this.authToken = ""
            getYXPictureCheckCode().then(res => {
                if (res.data.code === 0) {
                    this.codeUrl = `data:image/png;base64,${res.data.data.base64Image}`
                    this.authToken = res.data.data.token
                } else {
                    this.codeUrl = "";
                    this.authToken = ""
                    this.$message({
                        message: errcode.errCode[res.data.code].cn,
                        type: "error",
                        duration: 2000
                    });
                }
            }).catch(err => {
                this.codeUrl = "";
                this.authToken = ""
                let message = this.$i18n.t('message.common.systemError');
                if(err && err.data && err.data.code){
                    message = this.errcode.errCode.isCN?this.errcode.errCode[err.data.code].cn:this.errcode.errCode[err.data.code].en;
                }
                this.$message({
                    type: "error",
                    message: message
                });
            })
        },
        userLogin: function (callback) {
            delCookie('JSESSIONID')
            delCookie('NODE_MGR_ACCOUNT_C')
            let reqData = {
                account: this.loginForm.user,
                accountPwd: this.loginForm.password,//sha256(this.loginForm.password)
            };
            let checkCode = this.loginForm.vercode
            loginYX(reqData, checkCode, this.authToken)
                .then(res => {
                    if (res.data.code === 0) {
                        localStorage.setItem("groupName", "");
                        localStorage.setItem("groupId", "");
                        localStorage.setItem("folderList", "")
                        localStorage.setItem("user", res.data.data.account);
                        localStorage.setItem("root", res.data.data.roleName);
                        localStorage.setItem("token", res.data.data.token);
                        if(res.data.data.roleName == "admin"){
                            //不是元初的客户或供应商
                            localStorage.setItem("IsYuanChuAcc", "0");
                        }else{
                            //是元初的客户或供应商
                            localStorage.setItem("IsYuanChuAcc", "1");
                        }
                        sessionStorage.setItem("accountStatus", res.data.data.accountStatus);
                        sessionStorage.setItem("reload", 1);

                        localStorage.removeItem("orderSearchParams");
                        
                        this.getUserDetail(res.data.data);
                        // router.push("/main")
                    } else {
                        this.changeCode()
                        this.msgErrorContent = errcode.errCode[res.data.code].cn || ""
                        this.msgError = true;
                        this.loginForm.password = "";
                        this.logining = false;
                    }
                })
                .catch(err => {
                    this.changeCode()
                    this.timeout = true;
                    this.loginForm.password = "";
                    this.logining = false;
                });
        },
        getUserDetail(loginData){
            let reqData = {
                account:loginData.account,
            };
            let reqQuery = {};
            getAccountDetail(reqData,reqQuery).then(res => {
                this.logining = false;
                if (res.data.code === 0) {
                    localStorage.setItem("headImgUrl", res.data.data.avatar_show);
                    //超级管理员：显示所有菜单
                    if(loginData.roleName == "admin" && loginData.account == "admin"){
                        router.push("/main")
                    }
                    //普通管理员：显示
                    else if(loginData.roleName == "admin" && loginData.account != "admin"){
                        router.push("/accountList")
                    }
                    //普通成员：只显示业务管理模块
                    else{
                        router.push("/businessSearch")
                    }
                    
                } else {
                    let message = res.data.message?res.data.message:this.errcode.errCode.isCN?this.errcode.errCode[res.data.code].cn:this.errcode.errCode[res.data.code].en;
                    this.$message({
                        type: "error",
                        message: message
                    });
                }
            })
            .catch(err => {
                this.logining = false;
                let message = this.$i18n.t('message.common.systemError');
                if(err && err.data && err.data.code){
                    message = this.errcode.errCode.isCN?this.errcode.errCode[err.data.code].cn:this.errcode.errCode[err.data.code].en;
                }
                this.$message({
                    type: "error",
                    message: message
                });
            });
        }
    }
};
</script>
<style>
.login-label.is-required:not(.is-no-asterisk) > .el-form-item__label:before {
    content: "" !important;
}
.login-bg {
    position: relative;
    width: 100%;
    height: 100%;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    overflow-x: hidden;
}
.login-bg-child{
    position: absolute;
    /* min-width: 400px; */
    width: 23%;
    min-height: 570px;
    height: 65%;
    top: 17%;
    left: 60%;
    background-color: #fff;
    border-radius: 8px;
    box-sizing: border-box;
}
/* .login-bg-sub {
    position: absolute;
    width: calc(100% - 430px) ;
    height: 100%;
    top: 0%;
    left:0%;
    background-color: #fff;
    border-radius: 0px;
    box-sizing: border-box;
    background-size:cover;
    background-repeat: no-repeat;
} */
.login {
    min-width: 400px;
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0%;
    left: 0%;
    padding: 0 50px 0px 50px;
    background-color: #fff;
    border-radius: 10px;
    text-align: center;
    box-sizing: border-box;
}
.loginLogo{
    width: 100%;
    height: 25%;
}
.icon {
    top: 30px;
    width: 188px;
    height: 47px;
    /* vertical-align: -0.15em; */
    fill: currentColor;
    overflow: hidden;
}
.logo-content {
    position: absolute;
    width: 100%;
    top: 90px;
    left: 0;
    text-align: center;
    font-size: 25px;
    color: #979faa;
    letter-spacing: 0.02px;
}
.msg-wrapper {
    min-height: 20px;
    height: auto;
    /* margin: 5px 0; */
}
.msg-error {
    color: #e4393c;
}
.codeUrlImg {
    display: inline-block;
    height: 38px;
    width: 60px;
    line-height: 38px;
    padding-left: 16px;
    border: 1px solid #dcdfe6;
    border-radius: 2px;
    vertical-align: middle;
    cursor: pointer;
    /* background-color: #e4393c */
}
/* .logo {
    width: 120px;
    padding-top: 80px;
} */
.login-content {
    position: relative;
    top: 0px;
    height: auto;
}

.login-title {
    padding: 16px 0 0px 0;
    font-size: 20px;
    color: #2e2e2e;
    letter-spacing: 0.04px;
}

/* .login-label {
    position: relative;
    padding: 0 60px;
}
.login-label input {
    height: 54px;
    padding-left: 60px;
} */

/* .login-content .login-label .el-form-item__label {
    position: absolute !important;
    left: 52px !important;
    top: 12px !important;
    z-index: 999 !important;
    border-right: 1px solid #cfdae9 !important;
    height: 30px !important;
    line-height: 30px !important;
} */
.login-submit {
    position: relative;
    width: 100%;
    height: 45px;
    top: 0px;
    font-size: 14px;
}

.el-form-item.is-required:not(.is-no-asterisk) > .el-form-item__label:before {
    content: "";
}
.login-form .el-form-item__label {
    display: block;
    line-height: 32px;
    float: none;
    text-align: left;
}
.newItem /deep/ .el-form-item__error{
    color: #F56C6C;
    font-size: 12px !important;
    line-height: 1;
    position: absolute;
    top: 100%;
    left: 0px;
    padding-top: 5px;
}

.remarkNum{
    height:30px;
    width:100%;
    text-align:center;
    position: absolute;
    top:calc(100% - 80px);
    color:#fff;
}

.remarkNumSpanLeft{
    font-size:12px;
    color: #fff;
    display: block;
    line-height: 50px;
    position: absolute;
    float: left;
    left: 100px;
}
.remarkNumSpanRight{
    font-size:12px;
    color: #fff;
    line-height: 50px;
    float: right;
    position: absolute;
    left: calc(83% - 168px);
}
.remarkNumSpan{
    font-size:12px;
    color: #fff;
    display: inline-block;
    line-height: 50px;
}
.remarkNumSpanTouch{
    font-size:12px;
    color: #fff;
    display: inline-block;
    line-height: 50px;
    cursor: pointer;
    /* margin-right: 30px; */
}

.contant-head-name {
    position: relative;
    cursor: pointer;
}
.contant-head-name ul {
    position: absolute;
    width: 150%;
    left: -10px;
    top: 35px;
    background-color: #fff;
    color: #666;
    text-align: center;
    z-index: 9999999;
    box-shadow: 1px 4px 4px;
}
.contant-head-name ul li {
    width: 100%;
    padding: 0 10px;
    height: 32px;
    line-height: 32px;
    cursor: pointer;
}
.group-item-list {
    cursor: pointer;
    line-height: 32px;
    text-align: center;
    background-color: #fff;
}
.group-item-list:hover {
    line-height: 32px;
    text-align: center;
    background-color: #E1F7FE;
}

.loginlanauageClass{
    text-align: center;
    position: relative;
    background: initial;
    align-items: center; /*定义body的元素垂直居中*/
    justify-content: center; /*定义body的里的元素水平居中*/
}
.login-content /deep/ .el-form-item__content{
    text-align: left !important;
}

</style>
